Readme for CS2223 - Project 3 Knapsack Problem - Nikolas Gamarra

This project has no dependancies

To run my program simply run:
python Project3.py
in the command line while in the same directory as my file.

The program will open input-1.txt at default. You can specify another file simply by typing its name after the python file:
python Project3.py input-2.txt


The inputs I tested use the following naming convension
input-X.txt
where X is replace with a number 1-10
input-1.txt and input-2.txt are the two provided input examples. The others are were found or made. 
