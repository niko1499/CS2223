Readme for CS2223 - Project 2 Shortest distance between points - Nikolas Gamarra

This project has no dependancies

To run my program simply run:
python Project2.py
in the command line while in the same directory as my file.

The program will open input.txt at default. You can specify another file simply by typing its name after the python file:
python Project2.py input2.txt


The inputs I tested can be found in the inputX.txt files where X is replaced with a number. Including both the provided arrays as input.txt and input2.txt

Here are some examples on inputs
[(0, 0), (7, 6), (2, 20), (12, 5), (16, 16), (5, 8), (19, 7), (14, 22), (8, 19), (7, 29), (10, 11), (1, 13)]
[(0,1),(99,50),(153,22),(44,11),(45,11)]
55,99,00,99,33,44,66,11,22,66,33,99,88,44
[(5,6),(66,40),(143,25),(33,22)]
9347,4554,2354,74568,124,56784,234,6557,456,4567,2354,3784
46,77,50,68,22,53,26,96,15,11,77,47,77,46,56,27,79,52,13,14,23,55,22,88,97,17,23,22,82,87,88,9,90,32,24,77,76,90
74,52,41,27,90,16,55,74,16,50,92,30,3,57,90,97,59,80,23,16,1,97,53,55,22,100,59,98,74,14,58,71,5,100,17,38,60,31,77,59,36,77,38,27
