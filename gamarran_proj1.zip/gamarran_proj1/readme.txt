Readme for CS2223 - Project 1 Greatest Common Devisor - Nikolas Gamarra

Before you can run my program you will need the Python Memory Profiler Library and the Termcolor Library to get it run:
sudo easy_install -U memory_profiler # pip install -U memory_profiler
sudo apt-get install python-pip
sudo pip install termcolor
in the command line in your root directory.


To run my program simply run:
python Project1.py
in the command line while in the same directory as my file.

If you have dificulty installing the Library dependencies I have also encluded a bare bones version to run it enter:
python Project1Simple.py
in the command line while in the same directory as my file.
